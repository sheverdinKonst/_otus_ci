#ifndef LIB_H_
#define LIB_H_

#ifdef __cplusplus
extern "C" {
#endif

int print_data(const char* data);

#ifdef __cplusplus
};
#endif

#endif  // LIB_H_
